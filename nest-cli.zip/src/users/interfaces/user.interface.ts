export interface User {
    id:     number;
    nombre: string;
    email:  string;
    edad:   number;
    activo: boolean;
    rol:    string;
}
